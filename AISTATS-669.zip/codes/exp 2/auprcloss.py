import torch
import numpy as np
from torch.utils.data.sampler import Sampler
import random
import torch.nn as nn



class AUCPRSampler(Sampler):

    def __init__(self, labels, batchSize, posNum=1):
        # positive class: minority class
        # negative class: majority class

        self.labels = labels
        self.posNum = posNum
        self.batchSize = batchSize

        self.clsLabelList = np.unique(labels)
        self.dataDict = {}

        for label in self.clsLabelList:
            self.dataDict[str(label)] = []

        for i in range(len(self.labels)):
            self.dataDict[str(self.labels[i])].append(i)

        self.ret = []


    def __iter__(self):
        minority_data_list = self.dataDict[str(1)]
        majority_data_list = self.dataDict[str(0)]

        # print(len(minority_data_list), len(majority_data_list))
        random.shuffle(minority_data_list)
        random.shuffle(majority_data_list)

        # In every iteration : sample 1(posNum) positive sample(s), and sample batchSize - 1(posNum) negative samples
        if len(minority_data_list) // self.posNum  >= len(majority_data_list)//(self.batchSize - self.posNum): # At this case, we go over the all positive samples in every epoch.
            # extend the length of majority_data_list from  len(majority_data_list) to len(minority_data_list)* (batchSize-posNum)
            majority_data_list.extend(np.random.choice(majority_data_list, len(minority_data_list) // self.posNum * (self.batchSize - self.posNum) - len(majority_data_list), replace=True).tolist())

            for i in range(len(minority_data_list) // self.posNum):
                if self.posNum == 1:
                    self.ret.append(minority_data_list[i])
                else:
                    self.ret.extend(minority_data_list[i*self.posNum:(i+1)*self.posNum])

                startIndex = i*(self.batchSize - self.posNum)
                endIndex = (i+1)*(self.batchSize - self.posNum)
                self.ret.extend(majority_data_list[startIndex:endIndex])

        else: # At this case, we go over the all negative samples in every epoch.
            # extend the length of minority_data_list from len(minority_data_list) to len(majority_data_list)//(batchSize-posNum) + 1

            minority_data_list.extend(np.random.choice(minority_data_list, len(majority_data_list) // (self.batchSize - self.posNum) + 1 - len(minority_data_list)//self.posNum, replace=True).tolist())
            for i in range(0, len(majority_data_list), self.batchSize - self.posNum):

                if self.posNum == 1:
                    self.ret.append(minority_data_list[i//(self.batchSize - self.posNum)])
                else:
                    self.ret.extend(minority_data_list[i//(self.batchSize- self.posNum)* self.posNum: (i//(self.batchSize-self.posNum) + 1)*self.posNum])

                self.ret.extend(majority_data_list[i:i + self.batchSize - self.posNum])

        return iter(self.ret)


    def __len__ (self):
        return len(self.ret)





data_length = 25500 #CIFAR
#data_length = 26500 # Melanoma
class SOAPLOSS(nn.Module):
    def __init__(self, threshold, batch_size):
        '''
        :param threshold: margin for squred hinge loss
        '''
        super(SOAPLOSS, self).__init__()
        self.u_all = threshold**2/batch_size * torch.tensor([0]*data_length).view(-1, 1).cuda()
        self.u_pos = threshold**2/batch_size * torch.tensor([0]*data_length).view(-1, 1).cuda()
        self.threshold = threshold
        self.batch_size=batch_size


    def forward(self,f_ps, f_ns, index_s, gamma, optionP):
        f_ps = f_ps.view(-1)
        f_ns = f_ns.view(-1)
        vec_dat = torch.cat((f_ps, f_ns), 0)
        mat_data = vec_dat.repeat(len(f_ps), 1)


       #  print(mat_data.shape)

        f_ps = f_ps.view(-1, 1)

        neg_mask = torch.ones_like(mat_data)
        neg_mask[:, 0:f_ps.size(0)] = 0

        pos_mask = torch.zeros_like(mat_data)
        pos_mask[:, 0:f_ps.size(0)] = 1

        # test_tmp = f_ps- mat_data
        # print(f_ps.size(), mat_data.size(), test_tmp.size())

        # 3*1 - 3*64 ==> 3*64
        neg_loss = torch.max(self.threshold - (f_ps - mat_data), torch.zeros_like(mat_data)) ** 2 * neg_mask
        pos_loss = torch.max(self.threshold - (f_ps - mat_data), torch.zeros_like(mat_data)) ** 2 * pos_mask

        # print(torch.sum(pos_loss).item(), torch.mean(neg_loss).item())

  #       test_pos_loss = torch.sum(pos_loss)/torch.sum(pos_mask)
  #       test_neg_loss = torch.sum(neg_loss)/torch.sum(neg_mask)
        # print( "mean pos_loss:", round(test_pos_loss.item(), 2), "mean neg_loss:", round(test_neg_loss.item(),2), test_pos_loss.item() == pos_loss.mean())
        loss = pos_loss + neg_loss

        # print(loss.size(), pos_mask.size(), neg_mask.size(), loss.sum(1), pos_loss.sum(1))

        if f_ps.size(0) == 1:
            # sprint('We are using the version that for f_ps equals to 1')
            # print('---', self.u_all[0], loss.sum())
            self.u_pos[index_s] = (1 - gamma) * self.u_pos[index_s] + gamma * (pos_loss.mean())
            self.u_all[index_s] = (1 - gamma) * self.u_all[index_s] + gamma * (loss.mean())
        else:
            # print(self.u_all[index_s], loss.size(), loss.sum(1, keepdim = 1))
            self.u_all[index_s] = (1 - gamma) * self.u_all[index_s] + gamma * (loss.mean(1, keepdim=True))
            self.u_pos[index_s] = (1 - gamma) * self.u_pos[index_s] + gamma * (pos_loss.mean(1, keepdim=True))


        if optionP == 1:
            p = (self.u_pos[index_s] - (self.u_all[index_s]) * pos_mask) / (self.u_all[index_s] ** 2)
            # print(self.u_pos[index_s] - self.u_pos[index_s]*pos_loss)
        elif optionP == 2:
            # Simplied verrsion of p. The only one that shows works.
            p = loss / self.u_all[index_s]

        else:
            assert 'sssss'

        # print(p)

        p.detach_()

        loss = torch.sum(p * loss)
        loss = loss.mean()

        return loss


class MOAPLOSS(nn.Module):
    def __init__(self, threshold, batch_size,posNum):
        '''
        :param threshold: margin for squred hinge loss
        '''
        super(MOAPLOSS, self).__init__()
        self.u_all = threshold**2/batch_size * torch.tensor([0]*data_length).view(-1, 1).cuda()
        self.u_pos = threshold**2/batch_size * torch.tensor([0]*data_length).view(-1, 1).cuda()
        self.threshold = threshold
        self.batch_size=batch_size
        self.posnum=posNum


    def forward(self,f_ps, f_ns, index_s, gamma, optionP):
        f_ps = f_ps.view(-1)
        f_ns = f_ns.view(-1)
        vec_dat = torch.cat((f_ps, f_ns), 0)
        mat_data = vec_dat.repeat(len(f_ps), 1)
   

        f_ps = f_ps.view(-1, 1)

        neg_mask = torch.ones_like(mat_data)
        neg_mask[:, 0:f_ps.size(0)] = 0

        pos_mask = torch.zeros_like(mat_data)
        pos_mask[:, 0:f_ps.size(0)] = 1

        # test_tmp = f_ps- mat_data
        # print(f_ps.size(), mat_data.size(), test_tmp.size())

        # 3*1 - 3*64 ==> 3*64
        neg_loss = torch.max(self.threshold - (f_ps - mat_data), torch.zeros_like(mat_data)) ** 2 * neg_mask
        pos_loss = torch.max(self.threshold - (f_ps - mat_data), torch.zeros_like(mat_data)) ** 2 * pos_mask

        # print(torch.sum(pos_loss).item(), torch.mean(neg_loss).item())

  #       test_pos_loss = torch.sum(pos_loss)/torch.sum(pos_mask)
  #       test_neg_loss = torch.sum(neg_loss)/torch.sum(neg_mask)
        # print( "mean pos_loss:", round(test_pos_loss.item(), 2), "mean neg_loss:", round(test_neg_loss.item(),2), test_pos_loss.item() == pos_loss.mean())
        loss = pos_loss + neg_loss

        # print(loss.size(), pos_mask.size(), neg_mask.size(), loss.sum(1), pos_loss.sum(1))

        if f_ps.size(0) == 1:
            # sprint('We are using the version that for f_ps equals to 1')
            # print('---', self.u_all[0], loss.sum())
            self.u_pos= (1 - gamma) * self.u_pos
            self.u_all= (1 - gamma) * self.u_all
            self.u_pos[index_s] = self.u_pos[index_s] + gamma * (pos_loss.mean())*self.posnum/self.batch_size
            self.u_all[index_s] = self.u_all[index_s] + gamma * (loss.mean())*self.posnum/self.batch_size
        else:
            self.u_pos= (1 - gamma) * self.u_pos
            self.u_all= (1 - gamma) * self.u_all
            self.u_pos[index_s] = self.u_pos[index_s] + gamma * (pos_loss.mean(1, keepdim=True)) *self.posnum/self.batch_size
            self.u_all[index_s] = self.u_all[index_s] + gamma * (loss.mean(1, keepdim=True))*self.posnum/self.batch_size
            # print(self.u_all[index_s], loss.size(), loss.sum(1, keepdim = 1))



        if optionP == 1:
            p = (self.u_pos[index_s] - (self.u_all[index_s]) * pos_mask) / (self.u_all[index_s] ** 2)
            # print(self.u_pos[index_s] - self.u_pos[index_s]*pos_loss)
        elif optionP == 2:
            # Simplied verrsion of p. The only one that shows works.
            p = loss / self.u_all[index_s]

        else:
            assert 'sssss'

        # print(p)

        p.detach_()

        loss = torch.sum(p * loss)
        loss = loss.mean()

        return loss