import torch
from torch.utils.data import DataLoader
from torchvision.datasets.folder import ImageFolder
import numpy as np
from torchvision.models import resnet
from preprocess import *
from utils import *
from config import conf
from train_eval import *
from imbalanced_cifar import *
from torchvision import datasets

# train_dataset = ('/mnt/dive/shared/lyz/auprc_img/datasets/train', get_transform(input_size=conf['input_size'], augment=True))
# val_dataset = ImageFolder('/mnt/dive/shared/lyz/auprc_img/datasets/valid', get_transform(input_size=conf['input_size'], augment=False))
# test_dataset = ImageFolder('/mnt/dive/shared/lyz/auprc_img/datasets/test', get_transform(input_size=conf['input_size'], augment=False))

train_dataset = IMBALANCECIFAR10(root='./data', download=True, transform = transform_train)
val_dataset = IMBALANCECIFAR10(root='./data', download=True, transform=transform_train, val = True)
test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_val)



model = resnet18()
model_name = 'resnet18'


for conf['batch_size'] in [64]:
     for i in range(5):
         for loss_type in ['MOAP']:
             conf['ft_mode'] = 'fc_random'

             conf['pre_train'] = './cifar10_resnet18_002.ckpt'
             conf['epochs'] = 40
             conf['lr'] = 1e-6
             tau = 1
             posNum = 2
             out_path = './{}/cifar1022/results_{}_bth_{}_epoch_{}_lr_{}_ft_mode_{}_tau_{}_posNum_{}'.format(model_name, loss_type,  conf['batch_size'], conf['epochs'], conf['lr'], conf['ft_mode'],tau, posNum)
             if not os.path.exists(out_path):
                 os.makedirs(out_path)
             conf['loss_type'] = loss_type
             conf['loss_param'] = {'threshold':0.6, 'm':0.5, 'gamma':1000}
             print(conf)
             bins = 3
             run_classification(i, train_dataset, val_dataset, test_dataset, model, conf['num_tasks'], conf['epochs'], conf['batch_size'], conf['vt_batch_size'], conf['lr'], conf['lr_decay_factor'], conf['lr_decay_step_size'], conf['weight_decay'], conf['loss_type'], conf['loss_param'], conf['ft_mode'], conf['pre_train'], out_path,
                            bins = bins, tau = tau, posNum = posNum, dataset = 'cifar10')

