function [w_out]=moap(D_x,D_y,e,in_B,out_B,b,T,lambda,w,delta,mode)

D_p=D_x(D_y==1,:); 
d=length(w);
m=zeros(d,1); 
u=ones(length(D_p),2)*0.01; 
u(:,1)=0;
w_out=zeros(T,d);
w_out(1,:)=w;
v=zeros(d,1); 
p=length(D_p);



for i=1:T
    
eta=e/sqrt(i);
beta=b/sqrt(i);
in_sample_lab = randperm(size(D_p,1),in_B);%inner sample from positive sets
out_sample_lab = randperm(size(D_x,1),out_B);%outer sample from the whole set  

if strcmp(mode,'moap')
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   m=(1-beta)*m+beta*nabla_F_t;  
   w=w-(eta)*m;
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  
end

if strcmp(mode,'moap-std')
   eta=e;
   beta=b;
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   m=(1-beta)*m+beta*nabla_F_t;  
   w=w-(eta)*m;
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  
end

if strcmp(mode,'moapv2')   
   %sample 
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it'*(p/in_B);  %%%%%%%%%%%%%%%%    
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   %%%%%%%%%%%%%
   u(in_sample_lab,:)=u(in_sample_lab,:)/(1-beta);
   u=u*(1-beta);
   %%%%%%%%%%%%%
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   m=(1-beta)*m+beta*nabla_F_t;  
   w=w-eta*m;
   w_out(i,:)=w;    
end



if strcmp(mode,'moapadam')   

   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   m=(1-beta)*m+beta*nabla_F_t;
   v=(1-beta)*v+beta*diag(nabla_F_t*nabla_F_t');
   scr = v.^(1/2)+delta;
   w=w-eta*(m./scr);
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  
end


if strcmp(mode,'moapadamv2')
 
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it'*(p/in_B);  %%%%%%%%%%%%%%%%    
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   %%%%%%%%%%%%%
   u(in_sample_lab,:)=u(in_sample_lab,:)/(1-beta);
   u=u*(1-beta);  
   %%%%%%%%%%%%%
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   m=(1-beta)*m+beta*nabla_F_t; 
   v=(1-beta)*v+beta*diag(nabla_F_t*nabla_F_t');
   scr = v.^(1/2)+delta;
   w=w-eta*(m./scr);
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  

end

if strcmp(mode,'soap-std')
   eta=e;
   beta=b;
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   w=w-eta*nabla_F_t;
   w_out(i,:)=w;  
end

if strcmp(mode,'soap') 
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   w=w-eta*nabla_F_t;
   w_out(i,:)=w;  
end


if strcmp(mode,'moapadagrad')   

   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  

   v=v+diag(nabla_F_t*nabla_F_t');
   scr = (v/i).^(1/2)+delta;
   w=w-eta*(nabla_F_t./scr);
   w_out(i,:)=w;
end


if strcmp(mode,'smoothAP-std') 
   eta=e; 

   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle_smoothAP(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle_smoothAP(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2           
      nabla_f_inside = g_it;
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  

   w=w-eta*nabla_F_t;
   w_out(i,:)=w;  
end


if strcmp(mode,'smoothAP') 

   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle_smoothAP(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle_smoothAP(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2           
      nabla_f_inside = g_it;
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  

   w=w-eta*nabla_F_t;
   w_out(i,:)=w;  
end

if strcmp(mode,'soapadam')
   %sample

   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   v=(1-beta)*v+beta*diag(nabla_F_t*nabla_F_t');
   scr = (v).^(1/2)+delta;
   w=w-eta*(nabla_F_t./scr);
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  

end

if strcmp(mode,'soapadam-std')
   %sample
   eta=e;
   beta=b;
   in_sample_lab = randperm(length(D_p),in_B);%inner sample from positive sets
   out_sample_lab = randperm(length(D_x),out_B);%outer sample from the whole set  
   %compute tilde{\nabla}_t for each i in in_B
   nabla_F_t=zeros(d,1);
   for j=1:in_B
      g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'value');% 1*2
      nabla_g_it=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab(j),D_p,'gradient');%1*2
      u(in_sample_lab(j),:)=u(in_sample_lab(j),:)*(1-beta)+beta*g_it';      
      nabla_f_inside = u(in_sample_lab(j),:)';
      nabla_f=[ -1/nabla_f_inside(2), nabla_f_inside(1)/(nabla_f_inside(2))^2 ]';
      nabla_F_t=nabla_F_t+nabla_g_it'*nabla_f;
   end
   nabla_F_t=nabla_F_t/in_B+2*lambda*w;  
   v=(1-beta)*v+beta*diag(nabla_F_t*nabla_F_t');
   scr = (v).^(1/2)+delta;
   w=w-eta*(nabla_F_t./scr);
   w_out(i,:)=w;
   %ap = compute_AP(w,D_x, D_y,D_p)  

end




end






