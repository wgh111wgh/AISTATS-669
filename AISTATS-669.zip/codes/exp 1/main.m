
clc
clear
load w6a
D_x=train_x;
D_y=train_y;
D_x=(D_x-min(min(D_x)))/(max(max(D_x))-min(min(D_x)));
test_x=(test_x-min(min(test_x)))/(max(max(test_x))-min(min(test_x)));
D_p=D_x(D_y==1,:);
test_p=test_x(test_y==1,:);
%%%%%%%%%%%% parameters %%%%%%%%%%%%
d=size(D_x,2);
ratio=sum(D_y==1)/length(D_y);
in_B=20;  %# x_i
out_B=20; %# x_j, used by the oracle
T=500;
lambda=0.0001;
delta=10^(-5);
n_rep=4; %reps
c_eta=[20,10,1,0.1,0.01];
c_alg = {'moapv2','moapadamv2','smoothAP-std','soap-std','soapadam-std'};
c_beta=[0.9,0.5,0.1];


%%%%%search eta%%%%%%%
n_alg=length(c_alg);
n_eta=length(c_eta);
n_beta=length(c_beta);

ap=zeros(n_rep,n_eta,n_beta,n_alg);
w_all=zeros(n_rep,n_eta,n_beta,n_alg,T,d);



for i=1:n_rep
   for j=1:n_eta
       for l=1:n_beta
            for k=1:n_alg
                w_int=rand(size(D_x,2),1)-0.5;    
                w = moap(D_x,D_y,c_eta(j),in_B,out_B,c_beta(l),T,lambda,w_int,delta,c_alg(k));
                w_all(i,j,l,k,:,:)=w;
                ap(i,j,l,k) = compute_AP(w(end,:)',D_x,D_y,D_p)
            end
       end
   end
end


ap_mean=zeros(n_eta,n_beta,n_alg);

for j=1:n_eta
    for l=1:n_beta
        for k=1:n_alg
            ap_mean(j,l,k)=sum(ap(:,j,l,k));        
        end
    end
end

ap_mean_per_alg=zeros(n_eta,n_beta);
best_eta=zeros(n_alg,1);
best_beta=zeros(n_alg,1);


for k=1:n_alg
   ap_mean_per_alg(:,:)= ap_mean(:,:,k);
   [a,b]=find(ap_mean_per_alg==max(ap_mean_per_alg(:)));
   best_eta(k)=a(1);
   best_beta(k)=b(1);
   %[best_eta(k),best_beta(k)]=[a(1),b(1)];
end



dddddd=[100,200,300,400,500];
ap_inside = zeros(n_rep,n_alg,length(dddddd));

for i=1:n_rep
        for k=1:n_alg
            %[w]=moap(D_x,D_y,best_eta(k),in_B,out_B,beta,T,lambda,w_int,delta,alg(k));
            w=zeros(T,d);
            w(:,:)=w_all(i,best_eta(k),best_beta(k),k,:,:);            
                for j=1:length(dddddd)                   
                    ap_inside(i,k,j)=compute_AP(w(dddddd(j),:)',D_x, D_y,D_p)                 
                end
        end                      
end

ap_inside_fin=zeros(n_alg,length(dddddd));
var_inside_fin=zeros(n_alg,length(dddddd));
temp=zeros(n_alg,length(dddddd));
temp2=zeros(n_alg,length(dddddd));
for i=1:n_rep
   temp(:,:)=ap_inside(i,:,:) ;
   ap_inside_fin=temp + ap_inside_fin;
   
end
ap_inside_fin=ap_inside_fin/n_rep;

temp=zeros(n_rep,1);
for i=1:n_alg
    for j=1:length(dddddd)
        temp(:,:)=ap_inside(:,i,j);
        var_inside_fin(i,j)=var(temp);
    end
end



hold on
for i=1:n_alg
   errorbar(dddddd(:)',ap_inside_fin(i,:),var_inside_fin(i,:));
end

legend(c_alg)

%for a9a
%test_x(:,123)=0;
%test_p(:,123)=0;


ap_test=zeros(n_rep,n_alg);

for i=1:n_rep
        for k=1:n_alg
            %[w]=moap(D_x,D_y,best_eta(k),in_B,out_B,beta,T,lambda,w_int,delta,alg(k));
            w=zeros(T,d);
            w(:,:)=w_all(i,best_eta(k),best_beta(k),k,:,:);                           
            ap_test(i,k)=compute_AP(w(end,:)',test_x, test_y,test_p)                 
        end                      
end

ap_test=ap_test';
mean_test=mean(ap_test')
var_test=var(ap_test')










