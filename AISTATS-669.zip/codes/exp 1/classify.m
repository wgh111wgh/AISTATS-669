function output=classify(w,x,mode)

%&f(x) = 1 / [ exp(- w'x)+1  ]

if strcmp(mode,'value')
    output = 1 / ( exp(-w'*x') + 1);
end

if strcmp(mode,'gradient')
    output =( x' * exp (w'*x') * (1+ exp(w'*x') ) - x'*(exp(w'*x'))^2) / (1+ exp(w'*x'))^2;
end
    

