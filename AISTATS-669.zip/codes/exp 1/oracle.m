function output=oracle(w,D_x,D_y,out_sample_lab,in_sample_lab,D_p,mode)
%%suqare hinge loss 
%%ell(w;x_i;x_j) = [ max { 0 , m - ( f(x_i)-f(x_j) )  }]^2 + 0.1;



m = .1;
B = length(out_sample_lab);
d=length(w);
kk=0;

if strcmp(mode,'value')

temp_1 = 0;
temp_2 = 0;
f_i = classify(w,D_p(in_sample_lab,:),'value');

for j = 1 : B   
    
    f_j=classify(w,D_x(out_sample_lab(j),:),'value');
   % D_y(out_sample_lab(j))
    temp_1 = temp_1 + ((max(kk,m-(f_i-f_j)))^2) * (D_y(out_sample_lab(j))==1);   
    temp_2 = temp_2 + ((max(kk,m-(f_i-f_j)))^2);
    
end

output =[temp_1/B, temp_2/B]';

end


if strcmp(mode,'gradient')
        
est_grad=zeros(2,d);
f_i=classify(w,D_p(in_sample_lab,:),'value');
grad_i=classify(w,D_p(in_sample_lab,:),'gradient');

for j = 1 : B
   
    f_j=classify(w,D_x(out_sample_lab(j),:),'value');
    
    if m-(f_i-f_j)<=kk
        est_grad = est_grad;     
    else            
        grad_j=classify(w,D_x(out_sample_lab(j),:),'gradient'); 
        est_grad(1,:)=est_grad(1,:)+(2 * (m - (f_i-f_j)) * ( grad_j' -grad_i' ))* (D_y(out_sample_lab(j))==1) ;
        est_grad(2,:)=est_grad(2,:)+(2 * (m - (f_i-f_j)) * ( grad_j' -grad_i' )) ;     
    end    
end

output = est_grad / B;

end

