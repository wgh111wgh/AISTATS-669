function ap = compute_AP(w,D_x, D_y,D_p)


p = sum(D_y==1);
m = length(D_y);


temp=zeros(p,1); 
parfor i=1:p
    
   x_i =  D_p(i,:);
   temp_1=zeros(m,1);
   temp_2=zeros(m,1);
   for j=1:m
       x_j = D_x(j,:);
       temp_1(j)=(classify(w,x_j,'value')>=classify(w,x_i,'value'))* (D_y(j)==1);
       temp_2(j)=(classify(w,x_j,'value')>=classify(w,x_i,'value'));
   end
   temp(i)=sum(temp_1)/sum(temp_2);
end
ap=sum(temp)/p;